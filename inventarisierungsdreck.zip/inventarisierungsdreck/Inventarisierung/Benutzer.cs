﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Benutzer: DatabaseItem
    {
        private string Name;
        private string Kennwort;

        public string Name1
        {
            get { return Name; }
            set { Name = value; }
        }
        public string Kennwort1
        {
            get { return Kennwort; }
            set { Kennwort = value; }
        }
    }
}