﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventarisierung
{
    public class Datenhalter {
        DBManager dbman;
        public Datenhalter(DBManager dbman) {
            this.dbman = dbman;
        }

        private List<Gerätetyp> geräteList;
        private List<Kunde> kundeList;

        public List<Gerätetyp> GeräteList
        {
            get
            {
                return geräteList;
            }

            set
            {
                geräteList = value;
            }
        }

        public List<Kunde> KundeList
        {
            get
            {
                return kundeList;
            }

            set
            {
                kundeList = value;
            }
        }
        public bool createCustomer(string tb_KundennameHinzufügen, string tb_Straße, string tb_PLZ, string tb_Ort, string tb_EMail)
        {
            Kunde kn = new Kunde();
            kn.Name = tb_KundennameHinzufügen;
            kn.Straße = tb_Straße;
            kn.Plz = tb_PLZ;
            kn.Ort = tb_Ort;
            kn.EMail1 = tb_EMail;
            KundeList.Add(dbman.createNewCustomer(kn));
            return true;
        }
    }
    
}
