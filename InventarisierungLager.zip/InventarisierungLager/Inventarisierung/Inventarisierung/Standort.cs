﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Standort
    {
        private int Name;

        public Kunde Kunde
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Gerätetyp Gerätetyp
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void gehörtZuKunde()
        {
            throw new System.NotImplementedException();
        }
    }
}