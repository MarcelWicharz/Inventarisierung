﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class ListenFilter
    {
        public Inventarliste Inventarliste
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void showAllInaktivDevices()
        {
            throw new System.NotImplementedException();
        }

        public void showPCOlderThenThreeYears()
        {
            throw new System.NotImplementedException();
        }

        public void showAllDevicesFromPlaceX()
        {
            throw new System.NotImplementedException();
        }
    }
}