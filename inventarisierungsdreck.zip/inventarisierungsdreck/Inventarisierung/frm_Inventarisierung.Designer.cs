﻿namespace Inventarisierung
{
    partial class frm_Inventarisierung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Zurück = new System.Windows.Forms.Button();
            this.tb_Kundenname = new System.Windows.Forms.TextBox();
            this.lb_Kundenname = new System.Windows.Forms.Label();
            this.btn_Anlegen = new System.Windows.Forms.Button();
            this.lb_Inventarnummer = new System.Windows.Forms.Label();
            this.lb_KundenID = new System.Windows.Forms.Label();
            this.lb_Standort = new System.Windows.Forms.Label();
            this.lb_Gerätetyp = new System.Windows.Forms.Label();
            this.lb_Bezeichnung = new System.Windows.Forms.Label();
            this.lb_Rechnungsnummer = new System.Windows.Forms.Label();
            this.lb_Anlagedatum = new System.Windows.Forms.Label();
            this.lb_Memo = new System.Windows.Forms.Label();
            this.lb_InaktivAb = new System.Windows.Forms.Label();
            this.cb_Gerätetyp = new System.Windows.Forms.ComboBox();
            this.cb_Standort = new System.Windows.Forms.ComboBox();
            this.tb_KundenID = new System.Windows.Forms.TextBox();
            this.tb_InventarNr = new System.Windows.Forms.TextBox();
            this.tb_RechnungNr = new System.Windows.Forms.TextBox();
            this.tb_Anlagedatum = new System.Windows.Forms.TextBox();
            this.tb_Memo = new System.Windows.Forms.TextBox();
            this.tb_InaktiveAb = new System.Windows.Forms.TextBox();
            this.btn_Abmelden = new System.Windows.Forms.Button();
            this.tb_Bezeichnung = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Zurück
            // 
            this.btn_Zurück.Location = new System.Drawing.Point(550, 21);
            this.btn_Zurück.Name = "btn_Zurück";
            this.btn_Zurück.Size = new System.Drawing.Size(75, 23);
            this.btn_Zurück.TabIndex = 0;
            this.btn_Zurück.Text = "Zurück";
            this.btn_Zurück.UseVisualStyleBackColor = true;
            this.btn_Zurück.Click += new System.EventHandler(this.btn_Zurück_Click);
            // 
            // tb_Kundenname
            // 
            this.tb_Kundenname.Location = new System.Drawing.Point(91, 15);
            this.tb_Kundenname.Name = "tb_Kundenname";
            this.tb_Kundenname.ReadOnly = true;
            this.tb_Kundenname.Size = new System.Drawing.Size(134, 20);
            this.tb_Kundenname.TabIndex = 2;
            // 
            // lb_Kundenname
            // 
            this.lb_Kundenname.AutoSize = true;
            this.lb_Kundenname.Location = new System.Drawing.Point(12, 21);
            this.lb_Kundenname.Name = "lb_Kundenname";
            this.lb_Kundenname.Size = new System.Drawing.Size(73, 13);
            this.lb_Kundenname.TabIndex = 4;
            this.lb_Kundenname.Text = "Kundenname:";
            // 
            // btn_Anlegen
            // 
            this.btn_Anlegen.Location = new System.Drawing.Point(550, 233);
            this.btn_Anlegen.Name = "btn_Anlegen";
            this.btn_Anlegen.Size = new System.Drawing.Size(75, 23);
            this.btn_Anlegen.TabIndex = 5;
            this.btn_Anlegen.Text = "Anlegen";
            this.btn_Anlegen.UseVisualStyleBackColor = true;
            this.btn_Anlegen.Click += new System.EventHandler(this.btn_Anlegen_Click);
            // 
            // lb_Inventarnummer
            // 
            this.lb_Inventarnummer.AutoSize = true;
            this.lb_Inventarnummer.Location = new System.Drawing.Point(12, 67);
            this.lb_Inventarnummer.Name = "lb_Inventarnummer";
            this.lb_Inventarnummer.Size = new System.Drawing.Size(83, 13);
            this.lb_Inventarnummer.TabIndex = 6;
            this.lb_Inventarnummer.Text = "Inventarnummer";
            // 
            // lb_KundenID
            // 
            this.lb_KundenID.AutoSize = true;
            this.lb_KundenID.Location = new System.Drawing.Point(125, 66);
            this.lb_KundenID.Name = "lb_KundenID";
            this.lb_KundenID.Size = new System.Drawing.Size(58, 13);
            this.lb_KundenID.TabIndex = 7;
            this.lb_KundenID.Text = "Kunden ID";
            // 
            // lb_Standort
            // 
            this.lb_Standort.AutoSize = true;
            this.lb_Standort.Location = new System.Drawing.Point(189, 66);
            this.lb_Standort.Name = "lb_Standort";
            this.lb_Standort.Size = new System.Drawing.Size(47, 13);
            this.lb_Standort.TabIndex = 8;
            this.lb_Standort.Text = "Standort";
            // 
            // lb_Gerätetyp
            // 
            this.lb_Gerätetyp.AutoSize = true;
            this.lb_Gerätetyp.Location = new System.Drawing.Point(318, 66);
            this.lb_Gerätetyp.Name = "lb_Gerätetyp";
            this.lb_Gerätetyp.Size = new System.Drawing.Size(53, 13);
            this.lb_Gerätetyp.TabIndex = 9;
            this.lb_Gerätetyp.Text = "Gerätetyp";
            // 
            // lb_Bezeichnung
            // 
            this.lb_Bezeichnung.AutoSize = true;
            this.lb_Bezeichnung.Location = new System.Drawing.Point(12, 144);
            this.lb_Bezeichnung.Name = "lb_Bezeichnung";
            this.lb_Bezeichnung.Size = new System.Drawing.Size(69, 13);
            this.lb_Bezeichnung.TabIndex = 10;
            this.lb_Bezeichnung.Text = "Bezeichnung";
            // 
            // lb_Rechnungsnummer
            // 
            this.lb_Rechnungsnummer.AutoSize = true;
            this.lb_Rechnungsnummer.Location = new System.Drawing.Point(125, 144);
            this.lb_Rechnungsnummer.Name = "lb_Rechnungsnummer";
            this.lb_Rechnungsnummer.Size = new System.Drawing.Size(99, 13);
            this.lb_Rechnungsnummer.TabIndex = 11;
            this.lb_Rechnungsnummer.Text = "Rechnungsnummer";
            // 
            // lb_Anlagedatum
            // 
            this.lb_Anlagedatum.AutoSize = true;
            this.lb_Anlagedatum.Location = new System.Drawing.Point(244, 144);
            this.lb_Anlagedatum.Name = "lb_Anlagedatum";
            this.lb_Anlagedatum.Size = new System.Drawing.Size(69, 13);
            this.lb_Anlagedatum.TabIndex = 12;
            this.lb_Anlagedatum.Text = "Anlagedatum";
            // 
            // lb_Memo
            // 
            this.lb_Memo.AutoSize = true;
            this.lb_Memo.Location = new System.Drawing.Point(362, 144);
            this.lb_Memo.Name = "lb_Memo";
            this.lb_Memo.Size = new System.Drawing.Size(36, 13);
            this.lb_Memo.TabIndex = 13;
            this.lb_Memo.Text = "Memo";
            // 
            // lb_InaktivAb
            // 
            this.lb_InaktivAb.AutoSize = true;
            this.lb_InaktivAb.Location = new System.Drawing.Point(522, 144);
            this.lb_InaktivAb.Name = "lb_InaktivAb";
            this.lb_InaktivAb.Size = new System.Drawing.Size(60, 13);
            this.lb_InaktivAb.TabIndex = 14;
            this.lb_InaktivAb.Text = "Inaktive ab";
            // 
            // cb_Gerätetyp
            // 
            this.cb_Gerätetyp.FormattingEnabled = true;
            this.cb_Gerätetyp.Location = new System.Drawing.Point(321, 83);
            this.cb_Gerätetyp.Name = "cb_Gerätetyp";
            this.cb_Gerätetyp.Size = new System.Drawing.Size(121, 21);
            this.cb_Gerätetyp.TabIndex = 15;
            // 
            // cb_Standort
            // 
            this.cb_Standort.FormattingEnabled = true;
            this.cb_Standort.Location = new System.Drawing.Point(192, 83);
            this.cb_Standort.Name = "cb_Standort";
            this.cb_Standort.Size = new System.Drawing.Size(121, 21);
            this.cb_Standort.TabIndex = 16;
            // 
            // tb_KundenID
            // 
            this.tb_KundenID.Location = new System.Drawing.Point(128, 84);
            this.tb_KundenID.Name = "tb_KundenID";
            this.tb_KundenID.ReadOnly = true;
            this.tb_KundenID.Size = new System.Drawing.Size(58, 20);
            this.tb_KundenID.TabIndex = 17;
            // 
            // tb_InventarNr
            // 
            this.tb_InventarNr.Location = new System.Drawing.Point(15, 84);
            this.tb_InventarNr.Name = "tb_InventarNr";
            this.tb_InventarNr.Size = new System.Drawing.Size(107, 20);
            this.tb_InventarNr.TabIndex = 18;
            // 
            // tb_RechnungNr
            // 
            this.tb_RechnungNr.Location = new System.Drawing.Point(128, 161);
            this.tb_RechnungNr.Name = "tb_RechnungNr";
            this.tb_RechnungNr.Size = new System.Drawing.Size(100, 20);
            this.tb_RechnungNr.TabIndex = 20;
            // 
            // tb_Anlagedatum
            // 
            this.tb_Anlagedatum.Location = new System.Drawing.Point(247, 161);
            this.tb_Anlagedatum.Name = "tb_Anlagedatum";
            this.tb_Anlagedatum.Size = new System.Drawing.Size(100, 20);
            this.tb_Anlagedatum.TabIndex = 22;
            // 
            // tb_Memo
            // 
            this.tb_Memo.Location = new System.Drawing.Point(365, 161);
            this.tb_Memo.Name = "tb_Memo";
            this.tb_Memo.Size = new System.Drawing.Size(148, 20);
            this.tb_Memo.TabIndex = 23;
            // 
            // tb_InaktiveAb
            // 
            this.tb_InaktiveAb.Location = new System.Drawing.Point(525, 161);
            this.tb_InaktiveAb.Name = "tb_InaktiveAb";
            this.tb_InaktiveAb.Size = new System.Drawing.Size(100, 20);
            this.tb_InaktiveAb.TabIndex = 24;
            // 
            // btn_Abmelden
            // 
            this.btn_Abmelden.Location = new System.Drawing.Point(550, 51);
            this.btn_Abmelden.Name = "btn_Abmelden";
            this.btn_Abmelden.Size = new System.Drawing.Size(75, 23);
            this.btn_Abmelden.TabIndex = 25;
            this.btn_Abmelden.Text = "Abmelden";
            this.btn_Abmelden.UseVisualStyleBackColor = true;
            this.btn_Abmelden.Click += new System.EventHandler(this.btn_Abmelden_Click);
            // 
            // tb_Bezeichnung
            // 
            this.tb_Bezeichnung.Location = new System.Drawing.Point(12, 161);
            this.tb_Bezeichnung.Name = "tb_Bezeichnung";
            this.tb_Bezeichnung.Size = new System.Drawing.Size(100, 20);
            this.tb_Bezeichnung.TabIndex = 26;
            // 
            // frm_Inventarisierung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 267);
            this.Controls.Add(this.tb_Bezeichnung);
            this.Controls.Add(this.btn_Abmelden);
            this.Controls.Add(this.tb_InaktiveAb);
            this.Controls.Add(this.tb_Memo);
            this.Controls.Add(this.tb_Anlagedatum);
            this.Controls.Add(this.tb_RechnungNr);
            this.Controls.Add(this.tb_InventarNr);
            this.Controls.Add(this.tb_KundenID);
            this.Controls.Add(this.cb_Standort);
            this.Controls.Add(this.cb_Gerätetyp);
            this.Controls.Add(this.lb_InaktivAb);
            this.Controls.Add(this.lb_Memo);
            this.Controls.Add(this.lb_Anlagedatum);
            this.Controls.Add(this.lb_Rechnungsnummer);
            this.Controls.Add(this.lb_Bezeichnung);
            this.Controls.Add(this.lb_Gerätetyp);
            this.Controls.Add(this.lb_Standort);
            this.Controls.Add(this.lb_KundenID);
            this.Controls.Add(this.lb_Inventarnummer);
            this.Controls.Add(this.btn_Anlegen);
            this.Controls.Add(this.lb_Kundenname);
            this.Controls.Add(this.tb_Kundenname);
            this.Controls.Add(this.btn_Zurück);
            this.Name = "frm_Inventarisierung";
            this.Text = "frm_Inventarisierung";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Zurück;
        private System.Windows.Forms.TextBox tb_Kundenname;
        private System.Windows.Forms.Label lb_Kundenname;
        private System.Windows.Forms.Button btn_Anlegen;
        private System.Windows.Forms.Label lb_Inventarnummer;
        private System.Windows.Forms.Label lb_KundenID;
        private System.Windows.Forms.Label lb_Standort;
        private System.Windows.Forms.Label lb_Gerätetyp;
        private System.Windows.Forms.Label lb_Bezeichnung;
        private System.Windows.Forms.Label lb_Rechnungsnummer;
        private System.Windows.Forms.Label lb_Anlagedatum;
        private System.Windows.Forms.Label lb_Memo;
        private System.Windows.Forms.Label lb_InaktivAb;
        private System.Windows.Forms.ComboBox cb_Gerätetyp;
        private System.Windows.Forms.ComboBox cb_Standort;
        private System.Windows.Forms.TextBox tb_KundenID;
        private System.Windows.Forms.TextBox tb_InventarNr;
        private System.Windows.Forms.TextBox tb_RechnungNr;
        private System.Windows.Forms.TextBox tb_Anlagedatum;
        private System.Windows.Forms.TextBox tb_Memo;
        private System.Windows.Forms.TextBox tb_InaktiveAb;
        private System.Windows.Forms.Button btn_Abmelden;
        private System.Windows.Forms.TextBox tb_Bezeichnung;
    }
}