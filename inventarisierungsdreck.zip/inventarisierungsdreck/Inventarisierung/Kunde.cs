﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventarisierung
{
    public class Kunde:DatabaseItem
    {
        private string name;
        private string straße;
        private string plz;
        private string EMail;
        private string ort;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Straße
        {
            get { return straße; }
            set { straße = value; }
        }
        public string Plz
        {
            get { return plz; }
            set { plz = value; }
        }
        public string EMail1
        {
            get { return EMail; }
            set { EMail = value; }
        }
        public string Ort
        {
            get { return ort; }
            set { ort = value; }
        }
    }
}
