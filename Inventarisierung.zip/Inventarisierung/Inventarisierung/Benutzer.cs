﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventarisierung
{
    class Benutzer
    {
        private string benutzername;
        private string benutzerkennwort;

        public string Benutzername
        {
            get { return benutzername; }
            set { benutzername = value; } //"'Select Name From Benutzer //ganze liste
        }

        public string Benutzerkennwort
        {
            get { return benutzerkennwort; }
            set { benutzerkennwort = value; } //"'Select Kennwort From Benutzer //ganze liste
        }

        public Benutzer(string Benutzername, string Benutzerkennwort)
        {
            this.benutzername = Benutzername;
            this.benutzerkennwort = Benutzerkennwort;
        }

    }
}
