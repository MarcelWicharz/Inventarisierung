﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Gerätetyp : DatabaseItem
    {
        private string Name;
        public string Name1
        {
            get
            {
                return Name;
            }

            set
            {
                Name = value;
            }
        }
    }
}