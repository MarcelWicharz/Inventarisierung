﻿namespace Inventarisierung
{
    partial class frm_KundeÄndern
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_KundenID = new System.Windows.Forms.Label();
            this.tb_KundenName = new System.Windows.Forms.TextBox();
            this.btn_Zurück = new System.Windows.Forms.Button();
            this.tb_KundenID = new System.Windows.Forms.TextBox();
            this.btn_KundenDatenÄndern = new System.Windows.Forms.Button();
            this.lb_KundenDaten = new System.Windows.Forms.Label();
            this.lb_KundenName = new System.Windows.Forms.Label();
            this.lb_Straße = new System.Windows.Forms.Label();
            this.lb_PLZ = new System.Windows.Forms.Label();
            this.lb_Ort = new System.Windows.Forms.Label();
            this.lb_EMail = new System.Windows.Forms.Label();
            this.cb_KundeAuswählen = new System.Windows.Forms.ComboBox();
            this.tb_Straße = new System.Windows.Forms.TextBox();
            this.tb_PLZ = new System.Windows.Forms.TextBox();
            this.tb_Ort = new System.Windows.Forms.TextBox();
            this.tb_EMail = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lb_KundenID
            // 
            this.lb_KundenID.AutoSize = true;
            this.lb_KundenID.Location = new System.Drawing.Point(9, 70);
            this.lb_KundenID.Name = "lb_KundenID";
            this.lb_KundenID.Size = new System.Drawing.Size(61, 13);
            this.lb_KundenID.TabIndex = 0;
            this.lb_KundenID.Text = "Kunden ID:";
            // 
            // tb_KundenName
            // 
            this.tb_KundenName.Location = new System.Drawing.Point(99, 96);
            this.tb_KundenName.Name = "tb_KundenName";
            this.tb_KundenName.Size = new System.Drawing.Size(100, 20);
            this.tb_KundenName.TabIndex = 1;
            // 
            // btn_Zurück
            // 
            this.btn_Zurück.Location = new System.Drawing.Point(12, 249);
            this.btn_Zurück.Name = "btn_Zurück";
            this.btn_Zurück.Size = new System.Drawing.Size(75, 23);
            this.btn_Zurück.TabIndex = 3;
            this.btn_Zurück.Text = "Zurück";
            this.btn_Zurück.UseVisualStyleBackColor = true;
            this.btn_Zurück.Click += new System.EventHandler(this.btn_Zurück_Click);
            // 
            // tb_KundenID
            // 
            this.tb_KundenID.Location = new System.Drawing.Point(99, 67);
            this.tb_KundenID.Name = "tb_KundenID";
            this.tb_KundenID.ReadOnly = true;
            this.tb_KundenID.Size = new System.Drawing.Size(35, 20);
            this.tb_KundenID.TabIndex = 4;
            // 
            // btn_KundenDatenÄndern
            // 
            this.btn_KundenDatenÄndern.Location = new System.Drawing.Point(124, 249);
            this.btn_KundenDatenÄndern.Name = "btn_KundenDatenÄndern";
            this.btn_KundenDatenÄndern.Size = new System.Drawing.Size(75, 23);
            this.btn_KundenDatenÄndern.TabIndex = 5;
            this.btn_KundenDatenÄndern.Text = "Ändern";
            this.btn_KundenDatenÄndern.UseVisualStyleBackColor = true;
            this.btn_KundenDatenÄndern.Click += new System.EventHandler(this.btn_KundenDatenÄndern_Click);
            // 
            // lb_KundenDaten
            // 
            this.lb_KundenDaten.AutoSize = true;
            this.lb_KundenDaten.Location = new System.Drawing.Point(9, 9);
            this.lb_KundenDaten.Name = "lb_KundenDaten";
            this.lb_KundenDaten.Size = new System.Drawing.Size(74, 13);
            this.lb_KundenDaten.TabIndex = 6;
            this.lb_KundenDaten.Text = "Kundendaten:";
            // 
            // lb_KundenName
            // 
            this.lb_KundenName.AutoSize = true;
            this.lb_KundenName.Location = new System.Drawing.Point(9, 99);
            this.lb_KundenName.Name = "lb_KundenName";
            this.lb_KundenName.Size = new System.Drawing.Size(73, 13);
            this.lb_KundenName.TabIndex = 7;
            this.lb_KundenName.Text = "Kundenname:";
            // 
            // lb_Straße
            // 
            this.lb_Straße.AutoSize = true;
            this.lb_Straße.Location = new System.Drawing.Point(9, 130);
            this.lb_Straße.Name = "lb_Straße";
            this.lb_Straße.Size = new System.Drawing.Size(41, 13);
            this.lb_Straße.TabIndex = 8;
            this.lb_Straße.Text = "Straße:";
            // 
            // lb_PLZ
            // 
            this.lb_PLZ.AutoSize = true;
            this.lb_PLZ.Location = new System.Drawing.Point(9, 158);
            this.lb_PLZ.Name = "lb_PLZ";
            this.lb_PLZ.Size = new System.Drawing.Size(30, 13);
            this.lb_PLZ.TabIndex = 9;
            this.lb_PLZ.Text = "PLZ:";
            // 
            // lb_Ort
            // 
            this.lb_Ort.AutoSize = true;
            this.lb_Ort.Location = new System.Drawing.Point(9, 188);
            this.lb_Ort.Name = "lb_Ort";
            this.lb_Ort.Size = new System.Drawing.Size(24, 13);
            this.lb_Ort.TabIndex = 10;
            this.lb_Ort.Text = "Ort:";
            // 
            // lb_EMail
            // 
            this.lb_EMail.AutoSize = true;
            this.lb_EMail.Location = new System.Drawing.Point(9, 220);
            this.lb_EMail.Name = "lb_EMail";
            this.lb_EMail.Size = new System.Drawing.Size(36, 13);
            this.lb_EMail.TabIndex = 11;
            this.lb_EMail.Text = "EMail:";
            // 
            // cb_KundeAuswählen
            // 
            this.cb_KundeAuswählen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_KundeAuswählen.FormattingEnabled = true;
            this.cb_KundeAuswählen.Location = new System.Drawing.Point(12, 26);
            this.cb_KundeAuswählen.Name = "cb_KundeAuswählen";
            this.cb_KundeAuswählen.Size = new System.Drawing.Size(121, 21);
            this.cb_KundeAuswählen.TabIndex = 12;
            // 
            // tb_Straße
            // 
            this.tb_Straße.Location = new System.Drawing.Point(99, 127);
            this.tb_Straße.Name = "tb_Straße";
            this.tb_Straße.Size = new System.Drawing.Size(100, 20);
            this.tb_Straße.TabIndex = 13;
            // 
            // tb_PLZ
            // 
            this.tb_PLZ.Location = new System.Drawing.Point(99, 155);
            this.tb_PLZ.Name = "tb_PLZ";
            this.tb_PLZ.Size = new System.Drawing.Size(100, 20);
            this.tb_PLZ.TabIndex = 14;
            // 
            // tb_Ort
            // 
            this.tb_Ort.Location = new System.Drawing.Point(99, 185);
            this.tb_Ort.Name = "tb_Ort";
            this.tb_Ort.Size = new System.Drawing.Size(100, 20);
            this.tb_Ort.TabIndex = 15;
            // 
            // tb_EMail
            // 
            this.tb_EMail.Location = new System.Drawing.Point(99, 217);
            this.tb_EMail.Name = "tb_EMail";
            this.tb_EMail.Size = new System.Drawing.Size(100, 20);
            this.tb_EMail.TabIndex = 16;
            // 
            // frm_KundeÄndern
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(213, 277);
            this.Controls.Add(this.tb_EMail);
            this.Controls.Add(this.tb_Ort);
            this.Controls.Add(this.tb_PLZ);
            this.Controls.Add(this.tb_Straße);
            this.Controls.Add(this.cb_KundeAuswählen);
            this.Controls.Add(this.lb_EMail);
            this.Controls.Add(this.lb_Ort);
            this.Controls.Add(this.lb_PLZ);
            this.Controls.Add(this.lb_Straße);
            this.Controls.Add(this.lb_KundenName);
            this.Controls.Add(this.lb_KundenDaten);
            this.Controls.Add(this.btn_KundenDatenÄndern);
            this.Controls.Add(this.tb_KundenID);
            this.Controls.Add(this.btn_Zurück);
            this.Controls.Add(this.tb_KundenName);
            this.Controls.Add(this.lb_KundenID);
            this.Name = "frm_KundeÄndern";
            this.Text = "KundeÄndern";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_KundenID;
        private System.Windows.Forms.TextBox tb_KundenName;
        private System.Windows.Forms.Button btn_Zurück;
        private System.Windows.Forms.TextBox tb_KundenID;
        private System.Windows.Forms.Button btn_KundenDatenÄndern;
        private System.Windows.Forms.Label lb_KundenDaten;
        private System.Windows.Forms.Label lb_KundenName;
        private System.Windows.Forms.Label lb_Straße;
        private System.Windows.Forms.Label lb_PLZ;
        private System.Windows.Forms.Label lb_Ort;
        private System.Windows.Forms.Label lb_EMail;
        private System.Windows.Forms.ComboBox cb_KundeAuswählen;
        private System.Windows.Forms.TextBox tb_Straße;
        private System.Windows.Forms.TextBox tb_PLZ;
        private System.Windows.Forms.TextBox tb_Ort;
        private System.Windows.Forms.TextBox tb_EMail;
    }
}