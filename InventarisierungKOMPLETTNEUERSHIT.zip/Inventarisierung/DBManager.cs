﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Inventarisierung
{
    public class DBManager
    {
        private SqlConnection cn;
        private bool connectionOpened = false;

        //Methode zum öffnen der SQL-Verbindung
        private void openConnection()
        {
            if (connectionOpened)
            {
                throw new InvalidOperationException("Can't open another SQL-ConString");
            }
            this.cn = new SqlConnection("");
            cn.ConnectionString = @"Data Source=IF-PC42;
            Initial Catalog=Inventarisierung;
            User id=sa;
            Password=#ifaktor99;";
            cn.Open();
            connectionOpened = true;
        }
        //Methode zum schließen der SQL-Verbindung
        private void closeConnection()
        {
            this.cn.Close();
            this.connectionOpened = false;
        }

        public bool checkIfUsernameAndPasswordIsCorrect(string tb_Benutzername, string tb_Kennwort)
        {
            //Verbindungs String bauen
            openConnection();
            SqlCommand cmd = new SqlCommand($@"select Count(Benutzer.B_ID) From Benutzer where Name ='{ tb_Benutzername }' and Kennwort ='{ tb_Kennwort }'", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            var dtResult = new DataTable();
            dtResult.Load(dr);
            var count = dtResult.Rows[0][0].ToString();
            closeConnection();
            if (count == "1")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Datenhalter fillAndCreateDatenhalter()
        {
            Datenhalter halter = new Datenhalter(this);
            halter.GeräteList = readGeräteTypen();
            return null;   
        }
        private List<Gerätetyp> readGeräteTypen()
        {
            List<Gerätetyp> geräteListe = new List<Gerätetyp>();
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Select GeräteTyp.id,GeräteTyp.Name  From dbo.GeräteTyp", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            for (int i = 0; i < dtResult.Rows.Count; i++)
            {
                Gerätetyp gt = new Gerätetyp();
                gt.Id = int.Parse(dtResult.Rows[i][0].ToString());
                gt.Name1 = dtResult.Rows[i][1].ToString();
                geräteListe.Add(gt);
            }
            closeConnection();
            return geräteListe;
        }
        public void createNewUser(string tb_NeuerBenutzername, string tb_NeuesKennwort)
        {
            //Verbindungs String bauen
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Insert Into Benutzer (Name,Kennwort)values('{tb_NeuerBenutzername}','{tb_NeuesKennwort}')", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            closeConnection();
        }
        //CRUD
        //Create 1 Read * Update 1 Delete 1
        public Kunde createNewCustomer(Kunde kunde)
        {
            //Verbundungs String bauen
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Insert Into Kunde (Name,Straße,PLZ,Ort,EMail) OUTPUT Inserted.k_id values('{kunde.Name}','{kunde.Straße}','{kunde.Plz}','{kunde.Ort}','{kunde.EMail1}')", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            kunde.K_ID1 = int.Parse(dtResult.Rows[0][0].ToString());
            closeConnection();
            return kunde;
        }
    }
}
