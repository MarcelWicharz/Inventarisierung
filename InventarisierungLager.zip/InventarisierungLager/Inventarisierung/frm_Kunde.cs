﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_Kunde : Form
    {
        private List<Kunde> kunden;
        //Feld wird vllt benötigt um den ausgewählten Index der ComboBox zu speichern 
        //private Kunde selectedCustomer

        //Beim Form öffnen wird die ComboBox mit der Kundenliste gefüllt
        public frm_Kunde()
        {
            InitializeComponent();
            Datenbankverbindungen dbcon = new Datenbankverbindungen();
            kunden = dbcon.getAllCustomers();
            foreach(Kunde kunde in kunden)
            {
                this.cb_KundeAuswählen.Items.Add(kunde.K_ID1+ ":" + kunde.Name);
            }
        }
        //ComboBox
        private void cb_KundeAuswählen_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //Öffnet die Form Inventarisierung bei Button Klick und schließt die derzeitige
        private void btn_KundeAuswählen_Click(object sender, EventArgs e)
        {
            frm_Inventarisierung newMainForm = new frm_Inventarisierung();
            newMainForm.Show();
            this.Close();
        }
        //Öffnet die Form Kunde Hinzufügen bei Button Klick und schließt die derzeitige
        private void btn_NeuerKunde_Click(object sender, EventArgs e)
        {
            Datenbankverbindungen dbv = new Datenbankverbindungen();
            frm_KundeHinzufügen newMainForm = new frm_KundeHinzufügen(dbv);
            newMainForm.Show();
            this.Close();
        }
        //Öffnet die Form Standort Hinzufügen bei Button Klick und schließt die derzeitige
        private void btn_NeuerStandort_Click(object sender, EventArgs e)
        {
            frm_StandortHinzufügen newMainForm = new frm_StandortHinzufügen();
            newMainForm.Show();
            this.Close();
        }
        //Öffnet die Form Kunde Ändern bei Button Klick und schließt die derzeitige
        private void btn_KundeÄndern_Click(object sender, EventArgs e)
        {
            frm_KundeÄndern newMainForm = new frm_KundeÄndern();
            newMainForm.Show();
            this.Close();
        }

        private void btn_Zurück_Click(object sender, EventArgs e)
        {
            frm_Menü newMainForm = new frm_Menü();
            newMainForm.Show();
            this.Close();
        }
    }
}
