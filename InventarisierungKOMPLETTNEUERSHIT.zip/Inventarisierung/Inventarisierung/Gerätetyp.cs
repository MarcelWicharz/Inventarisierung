﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Gerätetyp
    {
        private string Name;

        public Inventarliste Inventarliste
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void wirdBenutztVon()
        {
            throw new System.NotImplementedException();
        }
    }
}