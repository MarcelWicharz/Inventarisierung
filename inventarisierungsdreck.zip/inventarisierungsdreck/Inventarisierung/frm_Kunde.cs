﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Inventarisierung
{
    public partial class frm_Kunde : Form
    {
        DBManager dbman;
        Datenhalter halter;
        private List<Kunde> kunden;

        //Beim Form öffnen wird die ComboBox mit der Kundenliste gefüllt
        public frm_Kunde(Datenhalter halter)
        {
            this.halter = halter;
            InitializeComponent();
            kunden = halter.KundeList;
            foreach(Kunde kunde in kunden)
            {
                this.cb_KundeAuswählen.Items.Add(kunde.Id+ ":" + kunde.Name);
            }
        }
        //ComboBox
        private void cb_KundeAuswählen_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_KundeAuswählen_Click(object sender, EventArgs e)
        {
            frm_Inventarisierung newMainForm = new frm_Inventarisierung(halter);
            newMainForm.Show();
            this.Close();
        }

        private void btn_NeuerKunde_Click(object sender, EventArgs e)
        {
            frm_KundeHinzufügen newMainForm = new frm_KundeHinzufügen(halter);
            newMainForm.Show();
            this.Close();
        }

        private void btn_NeuerStandort_Click(object sender, EventArgs e)
        {
            frm_StandortHinzufügen newMainForm = new frm_StandortHinzufügen(halter);
            newMainForm.Show();
            this.Close();
        }

        private void btn_KundeÄndern_Click(object sender, EventArgs e)
        {
            frm_KundeÄndern newMainForm = new frm_KundeÄndern(halter);
            newMainForm.Show();
            this.Close();
        }

        private void btn_Zurück_Click(object sender, EventArgs e)
        {
            frm_Menü newMainForm = new frm_Menü(dbman);
            newMainForm.Show();
            this.Close();
        }
    }
}
