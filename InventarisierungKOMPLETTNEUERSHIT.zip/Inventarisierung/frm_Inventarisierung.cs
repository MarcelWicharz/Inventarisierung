﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_Inventarisierung : Form
    {
        public frm_Inventarisierung()
        {
            InitializeComponent();
        }

        private void btn_Zurück_Click(object sender, EventArgs e)
        {
            frm_Kunde newMainForm = new frm_Kunde();
            newMainForm.Show();
            this.Close();
        }

        private void btn_Abmelden_Click(object sender, EventArgs e)
        {
            DBManager dbman = new DBManager();
            frm_Login newMainForm = new frm_Login(dbman);
            newMainForm.Show();
            this.Close();
        }

        private void btn_Anlegen_Click(object sender, EventArgs e)
        {

        }
    }
}
