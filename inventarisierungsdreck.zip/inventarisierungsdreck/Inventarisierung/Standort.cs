﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Standort:DatabaseItem
    {
        private string Name;
        private Kunde kunde;

        public string Name1
        {
            get { return Name; }
            set { Name = value; }
        }
        public Kunde Kunde
        {
            get { return kunde; }  
            set { kunde = value; }
        }
    }
}