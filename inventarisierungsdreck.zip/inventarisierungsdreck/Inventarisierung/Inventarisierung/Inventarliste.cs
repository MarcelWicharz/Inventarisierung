﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Inventarliste
    {
        private int InventarNr;
        private string Bezeichnung;
        private int RechnungsNr;
        private DateTime Anlagedatum;
        private string Memo;
        private DateTime InaktivAb;
        private int I_ID;
        private int K_ID;
        private int S_ID;
        private int G_ID;

        public Standort Standort
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Gerätetyp Gerätetyp
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Kunde Kunde
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}