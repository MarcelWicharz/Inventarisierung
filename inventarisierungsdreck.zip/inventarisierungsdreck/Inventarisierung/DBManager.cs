﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Inventarisierung
{
    public class DBManager
    {
        private SqlConnection cn;
        private bool connectionOpened = false;

        //Methode zum öffnen der SQL-Verbindung
        private void openConnection()
        {
            if (connectionOpened)
            {
                throw new InvalidOperationException("Can't open another SQL-ConString");
            }
            this.cn = new SqlConnection("");
            cn.ConnectionString = @"Data Source=IF-PC42;
            Initial Catalog=Inventarisierung;
            User id=sa;
            Password=#ifaktor99;";
            cn.Open();
            connectionOpened = true;
        }
        //Methode zum schließen der SQL-Verbindung
        private void closeConnection()
        {
            this.cn.Close();
            this.connectionOpened = false;
        }

        //Methode zum erstellen und füllen der Datenbanklisten
        public Datenhalter fillAndCreateDatenhalter()
        {
            Datenhalter halter = new Datenhalter(this);
            halter.GeräteList = readGeräteTypen();
            halter.KundeList = readKunden();
            halter.StandortList = readStandort();
            halter.InventarList = readInventarliste();
            return null;   
        }

        //Liste der Kunden
        private List<Kunde> readKunden()
        {
            List<Kunde> kundenListe = new List<Kunde>();
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Select Kunde.K_ID,Kunde.Name, Kunde.Straße, Kunde.PLZ, Kunde.Ort, Kunde.EMail From dbo.Kunde", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            for (int i = 0; i < dtResult.Rows.Count; i++)
            {
                Kunde kn = new Kunde();
                kn.Id = int.Parse(dtResult.Rows[i][0].ToString());
                kn.Name = dtResult.Rows[i][1].ToString();
                kn.Straße = dtResult.Rows[i][2].ToString();
                kn.Plz = dtResult.Rows[i][3].ToString();
                kn.Ort = dtResult.Rows[i][4].ToString();
                kn.EMail1 = dtResult.Rows[i][5].ToString();
                kundenListe.Add(kn);
            }
            closeConnection();
            return kundenListe;
        }
        //Liste der Standorte
        private List<Standort> readStandort()
        {
            List<Standort> standortListe = new List<Standort>();
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Select Standort.S_ID,Standort.Name From Standort", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            for (int i = 0; i < dtResult.Rows.Count; i++)
            {
                Standort so = new Standort();
                so.Id = int.Parse(dtResult.Rows[i][0].ToString());
                so.Name1 = dtResult.Rows[i][1].ToString();
                standortListe.Add(so);
            }
            closeConnection();
            return standortListe;
        }
        //Liste der Gerätetypen
        private List<Gerätetyp> readGeräteTypen()
        {
            List<Gerätetyp> geräteListe = new List<Gerätetyp>();
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Select GeräteTyp.G_id,GeräteTyp.Name From dbo.GeräteTyp", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            for (int i = 0; i < dtResult.Rows.Count; i++)
            {
                Gerätetyp gt = new Gerätetyp();
                gt.Id = int.Parse(dtResult.Rows[i][0].ToString());
                gt.Name1 = dtResult.Rows[i][1].ToString();
                geräteListe.Add(gt);
            }
            closeConnection();
            return geräteListe;
        }
        //Liste aller Datensätze in Inventarliste
        private List<Inventarliste> readInventarliste()
        {
            List<Inventarliste> inventarListe = new List<Inventarliste>();
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Select Invenarliste.I_ID, Invenarliste.K_ID,Invenarliste.S_ID, Invenarliste.G_ID, Invenarliste.InventarNR, 
            Invenarliste.Bezeichnung, Invenarliste.RechnungsNr,Invenarliste.Anlagedatum, Invenarliste.Memo, Invenarliste.InaktivAb From dbo.Inventarliste", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            for (int i = 0; i < dtResult.Rows.Count; i++)
            {
                Inventarliste il = new Inventarliste();
                il.Id = int.Parse(dtResult.Rows[i][0].ToString());
                il.Kunde1.Id = int.Parse(dtResult.Rows[i][1].ToString());
                il.Standort1.Id = int.Parse(dtResult.Rows[i][2].ToString());
                il.Gerätetyp1.Id = int.Parse(dtResult.Rows[i][3].ToString());
                il.InventarNr1 = dtResult.Rows[i][4].ToString();
                il.Bezeichnung1 = dtResult.Rows[i][5].ToString();
                il.RechnungsNr1 = int.Parse(dtResult.Rows[i][6].ToString());
                il.Anlagedatum1 = DateTime.Parse(dtResult.Rows[i][7].ToString());
                il.Memo1 = dtResult.Rows[i][8].ToString();
                il.InaktivAb1 = DateTime.Parse(dtResult.Rows[i][9].ToString());
                inventarListe.Add(il);
            }
            closeConnection();
            return inventarListe;
        }

        //Methode ob eingegebene Passwort = hinterlegtes passwort (LogIn Form)
        public bool checkIfUsernameAndPasswordIsCorrect(string tb_Benutzername, string tb_Kennwort)
        {
            openConnection();
            SqlCommand cmd = new SqlCommand($@"select Count(Benutzer.B_ID) From Benutzer where Name ='{ tb_Benutzername }' and Kennwort ='{ tb_Kennwort }'", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            var dtResult = new DataTable();
            dtResult.Load(dr);
            var count = dtResult.Rows[0][0].ToString();
            closeConnection();
            if (count == "1")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //Methode zum Anlegen eines neuen Benutzers
        public void createNewUser(string tb_NeuerBenutzername, string tb_NeuesKennwort)
        {
            //Verbindungs String bauen
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Insert Into Benutzer (Name,Kennwort)values('{tb_NeuerBenutzername}','{tb_NeuesKennwort}')", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            closeConnection();
        }
        //Methode zum Anlegen eines neuen Kundens
        public Kunde createNewCustomer(Kunde kunde)
        {
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Insert Into Kunde (Name,Straße,PLZ,Ort,EMail) Output Inserted.k_id values('{kunde.Name}','{kunde.Straße}','{kunde.Plz}','{kunde.Ort}','{kunde.EMail1}')", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            var dtResult = new DataTable();
            dtResult.Load(dr);
            kunde.Id = int.Parse(dtResult.Rows[0][0].ToString());
            closeConnection();
            return kunde;
        }
        //Methode zum Kunden Updaten
        public Kunde updateCustomer(Kunde kunde)
        {
            openConnection();
            SqlCommand cmd = new SqlCommand($@"Update dbo.Kunde set K_ID ='{kunde.Id/*kann das funktionieren?*/}',Name ='{kunde.Name}',Straße='{kunde.Straße}',PLZ='{kunde.Plz}',Ort='{kunde.Ort}',EMail='{kunde.EMail1}' where K_ID='{kunde.Id}'", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            closeConnection();
            return kunde;
        }
    }
}

