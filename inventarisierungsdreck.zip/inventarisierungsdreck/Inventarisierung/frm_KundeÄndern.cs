﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_KundeÄndern : Form
    {
        Datenhalter halter;
        private List<Kunde> kunden;
        public frm_KundeÄndern(Datenhalter halter)
        {
            InitializeComponent();
            kunden = halter.KundeList;
            foreach (Kunde kunde in kunden)
            {
                this.cb_KundeAuswählen.Items.Add(kunde.Id + ":" + kunde.Name);
            }
        }

        private void btn_Zurück_Click(object sender, EventArgs e)
        {
            frm_Kunde newMainForm = new frm_Kunde(halter);
            newMainForm.Show();
            this.Close();
        }

        private void btn_KundenDatenÄndern_Click(object sender, EventArgs e)
        {
            halter.updateCustomer(tb_KundenID.Text, tb_KundenName.Text, tb_Straße.Text, tb_PLZ.Text, tb_Ort.Text, tb_EMail.Text);
            MessageBox.Show($@"Der Kunde '{tb_KundenName.Text}' wurde erfolgreich Angelegt.");

            tb_KundenName.Clear();
            tb_Straße.Clear();
            tb_PLZ.Clear();
            tb_Ort.Clear();
            tb_EMail.Clear();
        }
    }
}
