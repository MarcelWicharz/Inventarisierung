﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Inventarliste: DatabaseItem
    {
        private string InventarNr;
        private string Bezeichnung;
        private int RechnungsNr;
        private DateTime Anlagedatum;
        private string Memo;
        private DateTime InaktivAb;
        private Kunde Kunde;
        private Standort Standort;
        private Gerätetyp Gerätetyp;

        public string InventarNr1
        {
            get { return InventarNr; }
            set { InventarNr = value; }
        }
        public string Bezeichnung1
        {
            get { return Bezeichnung; }
            set { Bezeichnung = value; }
        }
        public int RechnungsNr1
        {
            get { return RechnungsNr; }
            set { RechnungsNr = value; }
        }
        public DateTime Anlagedatum1
        {
            get { return Anlagedatum; }
            set { Anlagedatum = value; }
        }
        public string Memo1
        {
            get { return Memo; }
            set { Memo = value; }
        }
        public DateTime InaktivAb1
        {
            get { return InaktivAb; }
            set { InaktivAb = value; }
        }

        public Kunde Kunde1
        {
            get { return Kunde; }
            set { Kunde = value; }
        }
        public Standort Standort1
        {
            get { return Standort; }
            set { Standort = value; }
        }
        public Gerätetyp Gerätetyp1
        {
            get { return Gerätetyp; }
            set { Gerätetyp = value; }
        }
    }
}