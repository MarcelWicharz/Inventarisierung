﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_KundeHinzufügen : Form
    {
        Datenhalter halter;
        public frm_KundeHinzufügen(Datenhalter halter)
        {
            this.halter = halter;
            InitializeComponent();
        }
        private void btn_KundeHinzufügen_Click(object sender, EventArgs e)
        {
            halter.createCustomer(tb_KundennameHinzufügen.Text, tb_Straße.Text, tb_PLZ.Text, tb_Ort.Text, tb_EMail.Text);                     
            MessageBox.Show("Der Kunde " + tb_KundennameHinzufügen.Text + " wurde erfolgreich Angelegt.");

            tb_KundennameHinzufügen.Clear();
            tb_Straße.Clear();
            tb_PLZ.Clear();
            tb_Ort.Clear();
            tb_EMail.Clear();
        }
        private void btn_Zurück_Click(object sender, EventArgs e)
        {
            frm_Kunde newMainForm = new frm_Kunde(halter);
            newMainForm.Show();
            this.Close();
        }
    }
}
