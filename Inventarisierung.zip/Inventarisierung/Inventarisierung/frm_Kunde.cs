﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_Kunde : Form
    {
        public frm_Kunde()
        {
            InitializeComponent();
       
        }

        //Liste aller Kunden in der DB in der Combobox anzeigen lassen
        //private List<string> GetListFromDataTableColumn(DataTable Kunde,
        //int K_ID, string Name)
        //{
        //    List<string> result = new List<string>();
        //}

        private void btn_KundeAuswählen_Click(object sender, EventArgs e)
        {
            frm_Inventarisierung newMainForm = new frm_Inventarisierung();
            newMainForm.Show();
            this.Close();
        }

        private void btn_NeuerKunde_Click(object sender, EventArgs e)
        {
            frm_KundeHinzufügen newMainForm = new frm_KundeHinzufügen();
            newMainForm.Show();
            this.Close();
        }
    }
}
