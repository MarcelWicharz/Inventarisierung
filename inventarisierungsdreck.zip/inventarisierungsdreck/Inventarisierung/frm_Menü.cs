﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_Menü : Form
    {
        private DBManager dbman;
        public frm_Menü(DBManager dbman)
        {
            this.dbman = dbman;
            InitializeComponent();
        }

        private void btn_NeueBenutzer_Click(object sender, EventArgs e)
        {
            frm_Benutzerverwaltung newMainForm = new frm_Benutzerverwaltung(dbman);
            newMainForm.Show();
            this.Close();
        }

        private void btn_KundenAuswahl_Click(object sender, EventArgs e)
        {
            frm_Kunde newMainForm = new frm_Kunde(dbman.fillAndCreateDatenhalter());
            newMainForm.Show();
            this.Close();
        }

        private void btn_Abmelden_Click(object sender, EventArgs e)
        {            
            frm_Login newMainForm = new frm_Login(dbman);
            newMainForm.Show();
            this.Close();
        }
    }
}
