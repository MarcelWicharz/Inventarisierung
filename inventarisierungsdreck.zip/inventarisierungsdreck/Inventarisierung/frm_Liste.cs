﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventarisierung
{
    public partial class frm_Liste : Form
    {
        Datenhalter halter;
        public frm_Liste(Datenhalter halter)
        {
            this.halter = halter;
            InitializeComponent();
        }

        private void btn_Zurück_Click(object sender, EventArgs e)
        {
            //Zurück zur Inventarisierungs Form und Listen Form schließen.
            frm_Inventarisierung newMainForm = new frm_Inventarisierung(halter);
            newMainForm.Show();
            this.Close();
        }
    }
}
