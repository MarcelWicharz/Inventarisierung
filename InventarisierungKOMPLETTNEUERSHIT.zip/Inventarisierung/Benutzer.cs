﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inventarisierung
{
    public class Benutzer
    {
        private string Name;
        private string Kennwort;
    }
}