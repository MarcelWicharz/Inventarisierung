﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventarisierung
{
    public class Datenhalter
    {
        DBManager dbman;
        public Datenhalter(DBManager dbman)
        {
            this.dbman = dbman;
        }

        private List<Gerätetyp> geräteList;
        private List<Kunde> kundeList;
        private List<Standort> standortList;
        private List<Inventarliste> inventarList;

        public List<Kunde> KundeList
        {
            get { return kundeList; }       
            set { kundeList = value; }
        }
        public List<Standort> StandortList
        {
            get { return standortList; }
            set { standortList = value; }
        }
        public List<Gerätetyp> GeräteList
        {
            get { return geräteList; }
            set { geräteList = value; }
        }
        public List<Inventarliste> InventarList
        {
            get { return inventarList; }
            set { inventarList = value; }
        }

        //Methode um neuen Kunden anzulegen
        public bool createCustomer(string tb_KundennameHinzufügen, string tb_Straße, string tb_PLZ, string tb_Ort, string tb_EMail)
        {
            Kunde kn = new Kunde();
            kn.Name = tb_KundennameHinzufügen;
            kn.Straße = tb_Straße;
            kn.Plz = tb_PLZ;
            kn.Ort = tb_Ort;
            kn.EMail1 = tb_EMail;
            KundeList.Add(dbman.createNewCustomer(kn));
            return true;
        }
        public bool updateCustomer(int tb_KundenID, string tb_Kundenname, string tb_Straße, string tb_PLZ, string tb_Ort, string tb_EMail)
        {
            Kunde kn = new Kunde();
            kn.Id = tb_KundenID;
            kn.Name = tb_Kundenname;
            kn.Straße = tb_Straße;
            kn.Plz = tb_PLZ;
            kn.Ort = tb_Ort;
            kn.EMail1 = tb_EMail;
            KundeList.Add(dbman.updateCustomer(kn));
            return true;

        }

        //Methode um neun Standort anzulegen (Standorte hängen an Kunden)
        //public bool createLocation()
        //{
        //    Standort so = new Standort();
        //    so.Name1 =

        //    return true;
        //}
        ////Methode um neues Gerät anzulegen (Geräte hängen an Standorten)
        //public bool createDevice()
        //{
        //    Gerätetyp gt = new Gerätetyp();
        //    gt.Name1 =

        //    return true;
        //}
        ////Methode um eine neues Gerät zu Inventarisieren (kunde,standort und gerätetyp hängen an einem eintrag)
        public bool createInventarListDatensatz(int tb_KundenID, int cb_Standort, int cb_Gerätetyp, string tb_InventarNr,
        string tb_Bezeichnung, int tb_RechnungsNr, DateTime tb_Anlagedatum, string tb_Memo, DateTime tb_InaktiveAb)
        {
            Inventarliste il = new Inventarliste();
            il.Kunde1.Id = tb_KundenID;
            il.Standort1.Id = cb_Standort;
            il.Gerätetyp1.Id = cb_Gerätetyp;
            il.InventarNr1 = tb_InventarNr;
            il.Bezeichnung1 = tb_Bezeichnung;
            il.RechnungsNr1 = tb_RechnungsNr;
            il.Anlagedatum1 = tb_Anlagedatum;
            il.Memo1 = tb_Memo;
            il.InaktivAb1 = tb_InaktiveAb;
            return true;

        }
    }

}
