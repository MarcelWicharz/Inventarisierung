﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventarisierung
{
    class Login
    {
        //Inhalte der Benutzerliste mit den eingegebenen werten in der Login Form vergleichen
        //Bei treffer sende True sonst False
    }
}
